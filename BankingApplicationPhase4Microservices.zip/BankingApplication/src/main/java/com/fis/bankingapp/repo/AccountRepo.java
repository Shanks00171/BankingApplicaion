package com.fis.bankingapp.repo;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.BalanceNotFound;
import com.fis.bankingapp.model.Account;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface AccountRepo extends JpaRepository<Account, Long> {

	public abstract Account findByAccNoAndPassword(long accNo, String password);
	
	@Modifying
	@Query("Update Account a set a.balance = a.balance + ?2 where a.accNo = ?1")
	public abstract int deposit(long accNo, double amt) throws AccountNotFound;
	
	@Modifying
	@Query("Update Account a set a.balance = a.balance - ?2 where a.accNo = ?1")
	public abstract  int withdraw(long accNo, double amt) throws AccountNotFound, BalanceNotFound;

	@Modifying 
	@Query("Update Account a set a.password = ?2 where a.accNo = ?1")
	public abstract int updatePassword(long accNo, String newPassword);

	public abstract Account findByAccNo(long accNo);

}
