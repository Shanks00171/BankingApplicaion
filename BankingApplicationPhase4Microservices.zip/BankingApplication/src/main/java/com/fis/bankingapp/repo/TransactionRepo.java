package com.fis.bankingapp.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.bankingapp.model.Transaction;

public interface TransactionRepo extends JpaRepository<Transaction, Integer> {
	public abstract List<Transaction> findByDateOfTransBetween(LocalDate startDate, LocalDate endDate);

	public abstract List<Transaction> findAllByAccNoTo(long accNo);
}
