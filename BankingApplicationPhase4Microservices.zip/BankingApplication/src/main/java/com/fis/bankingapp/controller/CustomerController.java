package com.fis.bankingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapp.exceptions.AccountNotFound;
import com.fis.bankingapp.exceptions.PasswordIncorrect;
import com.fis.bankingapp.model.Customer;
import com.fis.bankingapp.service.CustomerService;

/*
  {
    "custName" : "Amit Kumar",
    "mobile" : 7004502113,
    "email": "shanks@gmail.com",
    "aadharNo": 001711710000,
    "dob": "1999-02-17",
    "age" : 23,
    "rAddress" : "Pune",
    "pAddress" : "TATA",
    "password" : "PP@51423" 

    }
    
 */

@RestController
@RequestMapping("/HomePage")
public class CustomerController {
	@Autowired
	CustomerService service;

	@PostMapping("/Register") // http://localhost:8080/HomePage/Register
	public String register(@RequestBody Customer customer) {
		return service.createUser(customer);
	}

	@GetMapping("/Log/{email}/{password}") // http://localhost:8080/HomePage/Login
	public String Log(@PathVariable("email") String email, @PathVariable("password") String password) {
		try {
			service.Login(email, password);
			return "redirect:/CustomerAccount";
		} catch (AccountNotFound | PasswordIncorrect e) {
			System.out.println("Exception Found " + e );
		}
		return "redirect:/Register";

	}
	
	@PutMapping("/UpdateCustomer") // http://localhost:8080/HomePage/UpdateCustomer
	public String customer(@RequestBody Customer customer) {
		return service.updateUser(customer);
	}

	
	@DeleteMapping("/DeleteAccount/{id}/{password}") // http://localhost:8080/HomePage/DeleteAccount
	public String Delete(@PathVariable("id") int id, @PathVariable("password") String password) {
		try{
			return service.deleteUser(id, password);		
		}catch(PasswordIncorrect p) {
			return "Incorrect Password";
		}
	}

}
