package com.fis.bankapplication.exceptions;

public class CustomerNotFound extends Exception {
	public CustomerNotFound(String message) {
		super(message);
	}
}
